/*
 * package com.cars.servlet;
 * 
 * import javax.servlet.RequestDispatcher; import
 * javax.servlet.ServletException; import
 * javax.servlet.annotation.MultipartConfig; import
 * javax.servlet.annotation.WebServlet; import javax.servlet.http.HttpServlet;
 * import javax.servlet.http.HttpServletRequest; import
 * javax.servlet.http.HttpServletResponse; import javax.servlet.http.Part;
 * import java.io.File; import java.io.IOException;
 * 
 * @WebServlet("/AddImage") // mapping is correct
 * 
 * @MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, maxFileSize = 1024 *
 * 1024 * 10, maxRequestSize = 1024 * 1024 * 50) public class AddImage extends
 * HttpServlet { private static final long serialVersionUID = 1L;
 * 
 * public AddImage() { super(); }
 * 
 * protected void doPost(HttpServletRequest request, HttpServletResponse
 * response) throws ServletException, IOException {
 * 
 * Part image = request.getPart("image"); String fileName =
 * image.getSubmittedFileName(); System.out.println(fileName);
 * 
 * String storePath = request.getServletContext().getRealPath(""); String
 * filePath = "photos" + File.separator + fileName;
 * 
 * System.out.println(storePath); System.out.println(filePath);
 * 
 * try { image.write(storePath + File.separator + filePath);
 * System.out.println("File uploaded"); } catch (Exception e) {
 * System.out.println("File not uploaded"); e.printStackTrace(); }
 * 
 * String displayPath = request.getContextPath() + "/" +
 * filePath.replace("\\", "/"); System.out.println(displayPath);
 * 
 * request.setAttribute("path", displayPath); RequestDispatcher rd =
 * request.getRequestDispatcher("/pages/photos.jsp"); rd.forward(request,
 * response); } }
 */