
package com.cars.dao;

import java.sql.*;
import java.util.ArrayList;

import com.cars.databse.DBConnection;
import com.cars.model.User;

public class UserDAO {
    private Connection conn;
    private PreparedStatement ps;

    public UserDAO() {
        try {
            this.conn = DBConnection.getConnection();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean register(User user) {
        boolean isRegistered = false;

        String query = "INSERT INTO user(user_name, email_address, phone_number, role, password) VALUES(?, ?, ?, ?, ?)";
        if (conn != null) {
            try {
                ps = conn.prepareStatement(query);
                ps.setString(1, user.getName());
                ps.setString(2, user.getEmail());
                ps.setString(3, user.getPhone());
                ps.setString(4, user.getRole());
                ps.setString(5, user.getPassword());

                if (ps.executeUpdate() > 0) {
                    isRegistered = true;
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return isRegistered;
    }


    public User login(String email) {
        User user = null;
        String query = "SELECT * FROM user WHERE email_address = ?";

        if (conn != null) {
            try {
                ps = conn.prepareStatement(query);
                ps.setString(1, email);

                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    user = new User();
                    user.setUserId(rs.getInt("user_id"));
                    user.setName(rs.getString("user_name"));
                    user.setEmail(rs.getString("email_address"));
                    user.setPhone(rs.getString("phone_number"));
                    user.setRole(rs.getString("role"));
                    user.setPassword(rs.getString("password"));
                    user.setCreatedAt(rs.getTimestamp("created_at"));
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return user;
    }

}
